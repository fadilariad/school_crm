import ExtendableError from './ExtendableError';

class ValidationError extends ExtendableError{

}

export default ValidationError
