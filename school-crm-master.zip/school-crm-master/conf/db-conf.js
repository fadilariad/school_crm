module.exports = {
    dbName: 'main'
}