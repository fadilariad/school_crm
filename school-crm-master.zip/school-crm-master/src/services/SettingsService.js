const dao = require('../dao/settingsDao');
const AbstractService = require('./AbstractService');

class SettingsService extends AbstractService {
    
    
}

module.exports = new SettingsService(dao);